using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace VehicleGarage.Tests
{
    public class Tests
    {

        private List<Vehicle> vehicles;

        [SetUp]
        public void Setup()
        {
    
            vehicles = new List<Vehicle>();

        }

        [Test]
        public void GarageConstructorShouldWork()
        {
            Garage garage = new Garage(5);

            Assert.AreEqual(garage.Capacity, 5);
            
        }

        [Test]
        public void VehicleConstructorShouldWorks()
        {
            Vehicle vehicle = new Vehicle("Tesla", "Y", "PB9999XX", 300);

            Assert.AreEqual(vehicle.Brand,"Tesla");
            Assert.AreEqual(vehicle.Model,"Y");
            Assert.AreEqual(vehicle.LicensePlateNumber, "PB9999XX");
            Assert.AreEqual(vehicle.BatteryLevel, 100);
            Assert.AreEqual(vehicle.IsDamaged, false);

        }

        [Test]
        public void AddVehicleMethodShouldWork()
        {
            Garage garage = new Garage(5);
            Vehicle vehicle = new Vehicle("Tesla", "Y", "PB9999XX", 300);

            Assert.AreEqual(garage.AddVehicle(vehicle),true);

            garage.AddVehicle(vehicle);
            Assert.AreEqual(garage.Vehicles.Count, 1);
         
        }

        [Test]
        public void AddVehicleMethodShouldReturnFalse()
        {
            Garage garage = new Garage(0);
            Vehicle vehicle = new Vehicle("Tesla", "Y", "PB9999XX", 300);

            Assert.AreEqual(garage.AddVehicle(vehicle), false);

            garage.AddVehicle(vehicle);
            Assert.AreEqual(garage.Vehicles.Count, 0);

        }

        [Test]
        public void AddVehicleMethodShouldReturnFalseWhenAlreadyAddedCar()
        {
            Garage garage = new Garage(5);
            Vehicle vehicle = new Vehicle("Tesla", "Y", "PB9999XX", 300);

            Assert.AreEqual(garage.AddVehicle(vehicle), true);

            garage.AddVehicle(vehicle);

            Assert.AreEqual(garage.Vehicles.Count, 1);

            Assert.AreEqual(garage.AddVehicle(vehicle), false);

        }


        [Test]
        public void DriveVehicleMethodShoudWork()
        {
            Garage garage = new Garage(5);
            Vehicle vehicle = new Vehicle("Tesla", "Y", "PB9999XX", 300);
            garage.AddVehicle(vehicle);

            Assert.AreEqual(vehicle.IsDamaged, false);

            garage.DriveVehicle("PB9999XX", 30, true);

            Assert.AreEqual(vehicle.BatteryLevel, 70);
            Assert.AreEqual(vehicle.IsDamaged, true);

            Assert.Throws<NullReferenceException>(
                ()=>garage.DriveVehicle("PB8888XX", 30, true), "Object reference not set to an instance of an object.");
        }

        [Test]
        public void DriveVehicleMethodTestInvalidInputs()
        {
            Garage garage = new Garage(5);
            Vehicle vehicle = new Vehicle("Tesla", "Y", "PB9999XX", 300);
            garage.AddVehicle(vehicle);

            garage.DriveVehicle("PB9999XX",110, true);

            Assert.AreEqual(vehicle.BatteryLevel, 100);

            garage.DriveVehicle("PB9999XX", 60, true);
            Assert.AreEqual(vehicle.BatteryLevel, 40);
           
            garage.DriveVehicle("PB9999XX", 60, true);
            Assert.AreEqual(vehicle.BatteryLevel, 40);

        }

        [Test]
        public void ChargeVehiclesMethodShouldWork()
        {
            Garage garage = new Garage(5);
            Vehicle vehicle = new Vehicle("Tesla", "Y", "PB9999XX", 100.0);
            garage.AddVehicle(vehicle);

            Vehicle vehicle2 = new Vehicle("Golf", "5", "EA8888EA", 100.0);
            garage.AddVehicle(vehicle2);

            garage.DriveVehicle("PB9999XX", 70, false);
            garage.DriveVehicle("EA8888EA", 70, false);

            int expectedValue = garage.ChargeVehicles(30);
            
            Assert.AreEqual(2, expectedValue);

            garage.DriveVehicle("PB9999XX", 50, false);
            garage.DriveVehicle("EA8888EA", 70, false);
            expectedValue = garage.ChargeVehicles(30);

            Assert.AreEqual(1, expectedValue);
            expectedValue = garage.ChargeVehicles(30);
            Assert.AreEqual(0, expectedValue);

        }


        [Test]
        public void RepairVehiclesMethodShouldWork()
        {
            Garage garage = new Garage(5);
            Vehicle vehicle = new Vehicle("Tesla", "Y", "PB9999XX", 100.0);
            garage.AddVehicle(vehicle);

            Vehicle vehicle2 = new Vehicle("Golf", "5", "EA8888EA", 100.0);
            garage.AddVehicle(vehicle2);

            garage.DriveVehicle("PB9999XX", 70, true);
            garage.DriveVehicle("EA8888EA", 70, true);
                     
            Assert.AreEqual(garage.RepairVehicles(), "Vehicles repaired: 2");

            garage.DriveVehicle("PB9999XX", 30, true);
            Assert.AreEqual(garage.RepairVehicles(), "Vehicles repaired: 1");

            Assert.AreEqual(garage.RepairVehicles(), "Vehicles repaired: 0");
        }

    }

}